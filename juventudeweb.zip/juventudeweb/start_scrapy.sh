#!/bin/bash

SCRAPY_PATH="/home/ubuntu/.local/lib/python2.7/site-packages/scrapy/cmdline.py"

cd /home/ubuntu/juventudeweb
mv scrapy_spider.log scrapy_spider.log.last

python $SCRAPY_PATH crawl ji_iphac
sleep 12m
python $SCRAPY_PATH crawl je_increment
sleep 12m
python $SCRAPY_PATH crawl ji_renapsi
sleep 2m

sudo shutdown

