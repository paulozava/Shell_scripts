# -*- coding: utf-8 -*-

import csv
import mysql.connector as mysql
from .settings import DB_HOST, DB_DATABASE, DB_USR, DB_PWD


class CsvWriterPipeline(object):
    def open_spider(self, spider):
        self.file = open('plainDataExtern.csv', 'a')

    def close_spider(self, spider):
        self.file.close()

    def process_item(self, item, spider):
        plain_data_writer = csv.writer(self.file)
        item.pop('sql')
        for line in item.values():
            plain_data_writer.writerow(line)
        return item

class MySQLServerWriterPipeline(object):

    def open_spider(self, spider):
        self.cxnx = mysql.connect(
            host=DB_HOST, user=DB_USR, passwd=DB_PWD,database=DB_DATABASE)

    def close_spider(self, spider):
        self.cxnx.close()

    def process_item(self, item, spider):
        cursor = self.cxnx.cursor()
        sql = item.pop('sql')
        insertions = [tuple(insertion) for insertion in item.values()]
        cursor.executemany(sql, insertions)
        self.cxnx.commit()
        return item