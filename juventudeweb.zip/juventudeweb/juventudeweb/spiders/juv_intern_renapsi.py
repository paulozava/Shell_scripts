# -*- coding: utf-8 -*-
import scrapy
from juventudeweb.spiders.resources.spider_atributes import JI_PARSER, JI_SQL
from juventudeweb.spiders.main.juv_intern import JuvInternMain

class JuvInternRenapsiSpider(JuvInternMain, scrapy.Spider):
    name = 'ji_renapsi'
    site_user = '37381902000125'
    site_passwd = 'plataformadf'

    def __init__(self, name=name, spider_user=site_user, spider_passwd=site_passwd):
        scrapy.Spider.__init__(self, name=name)
        self.user = spider_user
        self.passwd = spider_passwd
        self.parser_list = JI_PARSER
        self.sql_increment = JI_SQL.format('INSERT INTO',
                                           'bot.{}_increment'.format(name),
                                           'fk_{}_update_id'.format(name)
                                          )
        self.sql_update = JI_SQL.format('REPLACE INTO',
                                        'bot.{}_update'.format(name),
                                        'id'
                                        )