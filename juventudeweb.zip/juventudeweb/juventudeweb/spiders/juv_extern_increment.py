# -*- coding: utf-8 -*-
import scrapy
from juventudeweb.spiders.resources.spider_functions import *
from juventudeweb.spiders.resources.spider_atributes import JE_SQL, JE_PARSER


class JuvExternIncrementSpider(scrapy.Spider):
    name = 'je_increment'
    UNIDADES_FEDERACAO = ('AC', 'AL', 'AM', 'AP', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MG', 'MS', 'MT', 'PA', 'PB', 'PE', 'PI', 'PR', 'RJ', 'RN', 'RO', 'RR', 'RS', 'SC', 'SE', 'SP', 'TO')
    BUSCA_PELAS_CIDADES = ('SP')
    CURSOS_ID = courses_id('bot.juventude_extern')

    def start_requests(self):
        url = 'http://www.juventudeweb.mte.gov.br/indexPesquisaAprendizagemInternet.asp'
        yield scrapy.Request(url=url, callback=self.state_request)

    def state_request(self, response, ufs=UNIDADES_FEDERACAO, search_by_cities=BUSCA_PELAS_CIDADES):
        for uf in ufs:
            if uf in search_by_cities:
                res = scrapy.FormRequest(
                    'http://www.juventudeweb.mte.gov.br/manter_aprendizagem_internet.asp',
                    formdata={
                        'acao': 'consultar municipio', 'sguf': uf
                    },
                    callback=self.city_request
                )
                res.meta['uf_course'] = uf
            else:
                res = scrapy.FormRequest(
                'http://www.juventudeweb.mte.gov.br/manter_aprendizagem_internet.asp',
                    formdata={
                        'acao': 'consultarCursos', 'NOUsuario': 'Internet',
                        'SGUFCURSO': uf,
                        'NOMUNICIPIOCURSO': '', 'IDARCO': '', 'NOTITULO': '', 'NORAZAOSOCIAL': '',
                        'NOCURSOINSTITUICAO': '', 'TPConsulta': '2', 'NOFANTASIA': ''
                    },
                    callback=self.course_request
                )
            yield res

    def city_request(self, response):
        uf_course = response.meta['uf_course']
        for city in response.css('MUNICIPIO::attr(NOMUNICIPIO)').extract():
            yield scrapy.FormRequest(
                'http://www.juventudeweb.mte.gov.br/manter_aprendizagem_internet.asp',
                formdata={
                    'acao': 'consultarCursos', 'NOUsuario': 'Internet',
                    'SGUFCURSO': uf_course, 'NOMUNICIPIOCURSO': city,
                    'IDARCO': '', 'NOTITULO': '', 'NORAZAOSOCIAL': '',
                    'NOCURSOINSTITUICAO': '', 'TPConsulta': '2', 'NOFANTASIA': ''
                },
                callback=self.course_request
            )

    def course_request(self, response, db=CURSOS_ID):
        for course_id in response.css('::attr(IDCURSOINSTITUICAO)').extract():
            if int(course_id) not in db:
                yield scrapy.FormRequest(
                    'http://www.juventudeweb.mte.gov.br/manter_aprendizagem_internet.asp',
                    formdata={
                        'acao': 'consultarCursos', 'NOUsuario': 'Internet',
                        'IDCURSOINSTITUICAO': str(course_id),
                        'TPConsulta': '2'
                    },
                    callback=self.parse
                )

    def parse(self, response):
        parsed_response = {'sql': JE_SQL}
        parsed_specs = [time_stamp()]
        for data in JE_PARSER:
            to_search = 'INSTITUICAO row::attr(' + data + ')'
            parsed_specs.append(
                test_to_encode(response.css(to_search).extract_first())
            )

        parsed_specs.extend(
            ['1' if i != u'0' else '0' for i in response.css(
                'ROOTNATUREZADEFICIENCIA row::attr(IDNATUREZADEFICIENCIA)').extract()
            ]
        )

        parsed_specs.extend(
            ['1' if i != u'0' else '0' for i in response.css(
                'ROOTTIPOCOMUNICACAO row::attr(IDTIPOCOMUNICACAO)').extract()
            ]
        )

        parsed_response.update({1:parsed_specs})

        return parsed_response