# -*- coding: utf-8 -*-

from time import time
from .dao import Dao

def test_to_encode(test):
    try:
        return test.encode('utf_8', 'replace')
    except:
        return ''

def time_stamp():
    return str(int(time()))

def courses_id(table):
    dao = Dao(table)
    response = dao.sby_idcursoinstituicao()
    dao.close()
    return response