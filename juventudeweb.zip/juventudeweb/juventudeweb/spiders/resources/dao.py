import mysql.connector as mysql
from juventudeweb.settings import DB_HOST, DB_DATABASE, DB_USR, DB_PWD

class Dao():
    def __init__(self, table):
        self.connection = mysql.connect(
            host=DB_HOST, user=DB_USR,
            passwd=DB_PWD, database=DB_DATABASE
        )
        self.cursor = self.connection.cursor()
        self.table = table

    def close(self):
        self.connection.close()

    def sby_idcursoinstituicao(self):
        sql = 'select idcursoinstituicao from {};'.format(self.table)
        self.cursor.execute(sql)
        rows = self.cursor.fetchall()
        return self.__parse_data(rows)

    def __parse_data(self, item):
        response = [i[0] for i in item]
        return response