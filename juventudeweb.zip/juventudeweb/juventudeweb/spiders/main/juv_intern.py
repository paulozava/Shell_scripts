# -*- coding: utf-8 -*-
import scrapy
from juventudeweb.spiders.resources.spider_functions import *

class JuvInternMain():

    def __init__(self):
        self.user = None
        self.passwd = None
        self.parser_list = None
        self.sql_increment = None
        self.sql_update = None
        self.logger = scrapy.Spider.logger

    def start_requests(self):
        url = 'http://www.juventudeweb.mte.gov.br'
        yield scrapy.Request(url=url, callback=self.parse)

    def parse(self, response):
        yield scrapy.FormRequest(
            'http://www.juventudeweb.mte.gov.br',
            formdata={'txtIDUsuario':'', 'mensagem':'1',
                      'txtusuario':self.user, 'txtsenha': self.passwd,
                      'submit.x': '33', 'submit.y': '16'},
            callback=self.after_login
        )

    def after_login(self, response):
        if "authentication failed" in response.body:
            self.logger.error("Login falhou")
            return
        else:
            token = response.xpath('//*[@name="token"]/@value').extract_first()
            yield scrapy.FormRequest(
                'http://www.juventudeweb.mte.gov.br/index_cadastrar_curso_aprendizagem_novo.asp',
                formdata={
                    'token': token,
                    'idAplicacao': '206'
                },
                callback=self.access_cadastro
            )

    def access_cadastro(self, response):
        for situacao in ('N', 'A', 'D', 'P', 'C', 'I', 'R', 'O', 'E', 'U', 'SS', 'ET'):
            yield scrapy.FormRequest(
                'http://www.juventudeweb.mte.gov.br/pesquisaCursoONGXML.asp',
                formdata={
                    'flag': 'flagCosultarCursosFilial',
                    'IDInstituicao': self.user,
                    'NRCNPJ': self.user,
                    'NOUsuario': self.user,
                    'STAprovacao': situacao,
                    'rdModalidadeCurso': '2',
                    'TPConsulta': '1'
                },
                callback=self.busca_curso
            )

    def busca_curso(self, response):
        for curso in response.css('row::attr(IDCURSOINSTITUICAO)').extract():
            yield scrapy.FormRequest(
                'http://www.juventudeweb.mte.gov.br/pesquisaCursoONGXML.asp',
                formdata={
                    'flag': 'flagCursoNovo',
                    'IDCursoInstituicao': curso,
                    'NOUsuario': self.user
                },
                callback=self.parse_dados
            )


    def parse_dados(self, response):
        parsed_response = {'sql': ''}
        parse_specs = [
            test_to_encode(response.css('CURSO row::attr(IDCURSOINSTITUICAO)').extract_first()),
            time_stamp()
        ]
        for data in self.parser_list[0]:
            to_find = 'CURSO row::attr(' + data + ')'
            parse_specs.append(test_to_encode(response.css(to_find).extract_first()))

        for data in self.parser_list[1]:
            to_find = 'TBResponsavelCurso row::attr(' + data + ')'
            parse_specs.append(test_to_encode(response.css(to_find).extract_first()))

        parsed_response.update({1:parse_specs})

        parsed_response['sql'] = self.sql_update
        yield parsed_response

        parsed_response['sql'] = self.sql_increment
        yield parsed_response

