# -*- coding: utf-8 -*-
import scrapy
from juventudeweb.spiders.resources.spider_atributes import JI_PARSER, JI_SQL
from juventudeweb.spiders.main.juv_intern import JuvInternMain

class JuvInternIphacSpider(JuvInternMain, scrapy.Spider):
    name = 'ji_iphac'
    site_user = '11595331000138'
    site_passwd = 'iphac20181'

    def __init__(self, name=name, spider_user=site_user, spider_passwd=site_passwd):
        scrapy.Spider.__init__(self, name=name)
        self.user = spider_user
        self.passwd = spider_passwd
        self.parser_list = JI_PARSER
        self.sql_increment = JI_SQL.format('INSERT INTO',
                                           'bot.{}_increment'.format(name),
                                           'fk_{}_update_id'.format(name)
                                          )
        self.sql_update = JI_SQL.format('REPLACE INTO',
                                        'bot.{}_update'.format(name),
                                        'id'
                                        )